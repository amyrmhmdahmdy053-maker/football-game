Football 11v11 Android project. Build output: app/build/outputs/apk/debug/app-debug.apk
